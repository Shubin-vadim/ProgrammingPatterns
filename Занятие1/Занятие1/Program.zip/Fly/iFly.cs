﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Занятие1.Fly
{
    public interface iFly
    {
        void Fly();
    }
}
