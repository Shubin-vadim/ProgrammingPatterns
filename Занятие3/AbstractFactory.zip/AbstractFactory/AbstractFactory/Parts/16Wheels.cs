﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbstractFactory.Parts
{
    public class _16Wheels: Wheels
    {
        public _16Wheels()
        {
            Console.WriteLine("Колеса 16\"");
        }
    }
}
